use strict;
use warnings;
package Bar;

# ABSTRACT: A test package

our $VERSION = '4.9.1';

1;
