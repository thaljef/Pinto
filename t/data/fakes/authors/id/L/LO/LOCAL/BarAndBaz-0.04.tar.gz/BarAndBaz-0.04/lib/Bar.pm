package Bar;
our $VERSION = '0.04';
1
