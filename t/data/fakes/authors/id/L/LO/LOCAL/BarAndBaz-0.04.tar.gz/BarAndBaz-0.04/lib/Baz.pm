package Baz;
our $VERSION = '0.04';
1
