package Bar;
our $VERSION = '0.02';
1
