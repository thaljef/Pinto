package Foo::Bar::Baz;
our $VERSION = '0.03';
1
