package Bar;
our $VERSION = 'BOGUS';
1
