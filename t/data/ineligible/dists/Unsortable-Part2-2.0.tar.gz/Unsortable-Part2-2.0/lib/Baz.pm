package Baz;
our $VERSION = '1.0';
1
